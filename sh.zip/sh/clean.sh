#!/bin/bash

find /var/spool/asterisk/monitor -type f -mtime +1 -exec rm -rf {} \;
