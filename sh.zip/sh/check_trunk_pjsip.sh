#!/bin/sh


#переменная для хранения состояния
#1 - есть не зарегистрированные транки
#0 - нет проблемных транков
state=0;
counter=0; # количество проверок при state 1

mainSleep=600; # Общий timeout
errSleep=30; # timeout, если есть не зарегистрированный транк

let diver=300/${errSleep}; # делитель, для реализация выполнения части кода раз в минуту
						  # для примера 60/10=6

logFile=/var/log/check_trunk_pjsip.log;

checkRegPjsip () {
  today=`date "+%Y-%m-%d_%H:%M:%S"`; #получаем дату и время

  ALLTRUNKS=`/usr/sbin/asterisk -rx "pjsip show registrations" | grep -o 'Objects found: [0-9]*' | grep -o '[0-9]*'` # Смотрим сколько всего транков в системе
  REGTRUNKS=`/usr/sbin/asterisk -rx "pjsip show registrations" | grep Registered | wc -l` # Зарегистрированные  транки (все транки со статусом Registered)
  #ALLTRUNKS=10;# для теста

  if [ ${ALLTRUNKS} != ${REGTRUNKS} ]; then #Если есть статусы отличные от Registered
    echo "${today} - ошибка регистрации транка PJSIP" >> ${logFile}; # пишем в лог


    state=1; # установим состояни 1
    counter=$((${counter}+1)) #

    # первый раз и каждую минуту делать reload.
    # при sleep 10 во внутреннем while, нужно ставить % 6
    if  [ `expr ${counter} % ${diver}` == 0 ] || [ ${counter} == 1 ] ; then # первый раз и каждую минуту делать релоад.
      /usr/sbin/asterisk -rx "pjsip reload" > /dev/null 2>&1 # Делаем pjsip reload
      echo "${today} - попытка PJSIP reload" >> ${logFile}; # пишем в лог
    fi
  else

    if [ ${state} == 1 ]; then
      echo "${today} - восстановленна нормальная работа транков PJSIP" >> ${logFile}; # пишем в лог
    fi

    state=0;
    counter=0;
  fi

}

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


while [ 1 ]
do
  checkRegPjsip

  while [ ${state} == 1 ] # Если состояние 1(проблема) значит чаще запускать скрипт
  do
    sleep ${errSleep}
    checkRegPjsip
  done


  sleep ${mainSleep}
done


