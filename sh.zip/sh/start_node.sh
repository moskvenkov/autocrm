#!/usr/bin/env bash


sleep 5

cd /var/www/autoobzvon/AMI
npm run pm2prod

sleep 5

cd /var/www/autoobzvon/ui
npm run pm2prod


