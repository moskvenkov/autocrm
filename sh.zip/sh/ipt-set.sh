#!/bin/bash

export IPT="iptables"
#Интерфейс
export KRV_IP=109.172.51.91/32

export WAN=eth0
export WAN_IP=176.9.230.10

#Удалить все правила
$IPT -F
#Удалить все правила в цепочках nat and mangle
$IPT -F -t nat
$IPT -F -t mangle
#удалить пользовательские цепочки
$IPT -X

$IPT -t nat -X
$IPT -t mangle -X

# блокировать трафик, если он не совпадает с правилами
$IPT -P INPUT DROP
#$IPT -P OUTPUT DROP
#$IPT -P FORWARD DROP

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~>> SIP <<~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
$IPT -N SIP
# доступ SIP
$IPT -A SIP -p udp -m udp -m string --string "sipcli" --algo bm --to 65535 -j DROP
$IPT -A SIP -p udp -m udp -m string --string "friendly-scanner" --algo bm --to 65535 -j DROP
$IPT -A SIP -p udp -m udp -m string --string "VaxSIPUserAgent" --algo bm --to 65535 -j DROP
$IPT -A SIP -p udp -m udp -m string --string "sip-scan" --algo bm --to 65535 -j DROP
$IPT -A SIP -p udp -m udp -m string --string "iWar" --algo bm --to 65535 -j DROP
$IPT -A SIP -p udp -m udp -m string --string "sipvicious" --algo bm --to 65535 -j DROP
$IPT -A SIP -p udp -m udp -m string --string "sipsak" --algo bm --to 65535 -j DROP
$IPT -A SIP -p udp -m udp -m string --string "sundayddr" --algo bm --to 65535 -j DROP
$IPT -A SIP -p udp -m udp -m string --string "Linksys/SPA942" --algo bm --to 65535 -j DROP
$IPT -A SIP -p udp -m udp -m string --string "pplsip" --algo bm --to 65535 -j DROP
$IPT -A SIP -p udp -m udp -m string --string "VoIP SIP v11.0.0" --algo bm --to 65535 -j DROP
$IPT -A SIP -p udp -m udp -j ACCEPT
#===========================================>> SIP <<=================================================

# разрешить установленные соединения
$IPT -A  INPUT -p all -m state --state ESTABLISHED,RELATED -j ACCEPT
$IPT -A  OUTPUT -p all -m state --state ESTABLISHED,RELATED -j ACCEPT
$IPT -A  FORWARD -p all -m state --state ESTABLISHED,RELATED -j ACCEPT

# Разрешить на локалхост
$IPT -A INPUT -i lo -j ACCEPT

# блокирование пакетов, которые не имеют статуса
$IPT -A INPUT -m state --state INVALID -j DROP
$IPT -A FORWARD -i $WAN -m state --state INVALID -j DROP

# блокирование нулевых пакетов
$IPT -A INPUT -p tcp --tcp-flags ALL NONE -j DROP

# блокирование syn-flood атак
$IPT -A INPUT -p tcp ! --syn -m state --state NEW -j DROP
$IPT -A OUTPUT -p tcp ! --syn -m state --state NEW -j DROP

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~>> PING <<~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# разрешить ping
# ответы ping
$IPT -A INPUT -p icmp --icmp-type echo-reply -j ACCEPT
# недоступность
$IPT -A INPUT -p icmp --icmp-type destination-unreachable -j ACCEPT
# привышение лимита времени
$IPT -A INPUT -p icmp --icmp-type time-exceeded -j ACCEPT
# запросы ping
$IPT -A INPUT -p icmp --icmp-type echo-request -j ACCEPT
#===========================================>> PING <<================================================

# досутп по ssh
$IPT -A INPUT -i $WAN -p tcp --dport 45022 -j ACCEPT

# SIP
$IPT -A INPUT -i $WAN -p udp -m udp --dport 5060:5069 -j SIP
# RTSP
$IPT -A INPUT -i $WAN -p udp -m udp --dport 10000:20000 -j ACCEPT

# приложение nodejs
$IPT -A INPUT -i $WAN -p tcp -m tcp --dport 9000 -j ACCEPT

# доступ web. nginx
$IPT -A INPUT -i $WAN -p tcp --dport 80 -j ACCEPT
$IPT -A INPUT -i $WAN -p tcp --dport 443 -j ACCEPT
#$IPT -A INPUT -i $WAN -p tcp --dport 9001 -j ACCEPT
#$IPT -A INPUT -i $WAN -p tcp --dport 8912 -j ACCEPT


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~>> Сохранить правила <<~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/sbin/iptables-save > /etc/sysconfig/iptables
# Для добаления правил от fail2ban
systemctl restart fail2ban



