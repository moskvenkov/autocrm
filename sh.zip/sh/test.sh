#!/bin/sh

echo `date`
./test2.sh > /dev/null &
echo `date`
