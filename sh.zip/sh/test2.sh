#!/bin/bash

echo test2 -`date`
sleep 20
echo test2 - `date`

