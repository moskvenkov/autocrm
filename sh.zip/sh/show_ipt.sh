#!/bin/sh

 watch -n 1 'iptables -L -vn --line-numbers'
