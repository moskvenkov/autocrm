#!/bin/sh

mov () {
#  echo "~~~~~~~~~~~~~~~~~~"
#  echo "enter="$1
  # получить путь к файлу без имени
  filePath=`echo $1| grep -o '/.*/'`
#  echo "filePath="$filePath
  # получить имя файла без расширения
  fileName=`echo ${1##/*/} | sed s/\.wav//`
# echo "fileName="$fileName > /tmp/fileName
  # получить абсолютный путь с новым расширением
  resultName=${filePath}${fileName}.mp3
#  echo "resultName="$resultName
  # конвертировать файл и удалить старый
  nice -n 19 /usr/bin/lame -b 16  --silent $1 $resultName && rm -rf $1 && \
  php /var/www/autoobzvon/api/bin/console.php z:ConvertFormat $fileName > /dev/null &
}

echo "begin" `date "+%Y-%m-%d_%H:%M"`

find $1 -name '*.wav' | while read dir; do
  mov $dir > /dev/null
done
echo "end" `date "+%Y-%m-%d_%H:%M"`

