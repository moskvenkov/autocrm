//файлы systemd переместить в /etc/systemd/service

chmod 0744 check_trunk_pjsip.sh
chmod 0744 check_trunk_sip.sh

mv check-sip.service /etc/systemd/system
mv check-pjsip.service /etc/systemd/system 

//перезапустить демон systemd
systemctl daemon-reload

//запустить их через 
systemctl start check-pjsip
systemctl start check-sip 

//добавить в автозагрузку
systemctl enable check-pjsip
systemctl enable check-sip

//добавить в автозагрузку
systemctl disable check-pjsip
systemctl disable check-sip

скрипты поместить по адресу /root/sh или в другое место и изменить расположение в файлах  systemd


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//если нет systemd(


mv check-pjsip /etc/init.d/
mv check-sip /etc/init.d/

//добавить в автозагрузку
chkconfig  --add check-pjsip
//проверить
chkconfig  --list check-pjsip

//добавить в автозагрузку
chkconfig  --add check-sip
//проверить
chkconfig  --list check-sip


