#!/bin/sh

logfile=/var/lib/asterisk/agi-bin/log/kaldi.log


file_path=$1

#file_path=/tmp/records/1588058881.8.wav



text=`/opt/vosk-server/websocket/test.py ${file_path}  | jq '.text' | tr  -d 'null' | tr -d '\n' | sed 's/\"/ /g' | sed 's/^\ //g' | sed 's/\ \ / /g' | sed 's/ $//g' | sed 's/ $//g'`


echo 'SET VARIABLE TEXT "'${text}'"'
